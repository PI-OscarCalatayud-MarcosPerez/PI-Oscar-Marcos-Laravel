<?php $__env->startSection('content'); ?>
<div class="contenedor-formulario-principal">
    <div class="caja-formulario">
        <h1>Contacta con nosotros</h1>
        <p class="subtitulo-form">¿Tienes dudas con tu clave? Envíanos un mensaje.</p>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success" style="background-color: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('contacto.store')); ?>" method="POST" id="formulario">
            <?php echo csrf_field(); ?>
            <div class="grupo-input">
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" placeholder="Tu nombre completo" required value="<?php echo e(old('nombre')); ?>" />
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error" style="color:red; font-size: 0.8em;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grupo-input">
                <label for="correo">Correo:</label>
                <input type="email" id="correo" name="correo" placeholder="tucorreo@email.com" required value="<?php echo e(old('correo')); ?>" />
                <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error" style="color:red; font-size: 0.8em;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="grupo-input">
                <label for="asunto">Asunto:</label>
                <select id="asunto" name="asunto" required>
                    <option value="">Seleccione un asunto</option>
                    <option value="informacion">Información General</option>
                    <option value="soporte">Soporte Técnico</option>
                    <option value="ventas">Ventas</option>
                </select>
            </div>

            <div class="grupo-input">
                <label for="Telefono">Teléfono:</label>
                <input type="tel" id="Telefono" name="telefono" placeholder="+34 600 000 000" value="<?php echo e(old('telefono')); ?>" />
            </div>

            <div class="grupo-input">
                <label for="mensaje">Mensaje / Consulta:</label>
                <textarea id="mensaje" name="mensaje" rows="5" required placeholder="Escribe aquí tu consulta..."><?php echo e(old('mensaje')); ?></textarea>
            </div>

            <div class="grupo-checkbox">
                <label>
                    <input type="checkbox" name="consentimiento" required />
                    Acepto el tratamiento de los datos
                </label>
            </div>

            <button type="submit" class="btn-enviar">Enviar Mensaje</button>
        </form>
    </div>
</div>

<div class="container-fluid breadcrumb-container" style="margin-top: 20px;">
    <div class="container px-md-5">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" style="color:#fa4841; text-decoration:none;">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page">Contacto</li>
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/contacto/index.blade.php ENDPATH**/ ?>