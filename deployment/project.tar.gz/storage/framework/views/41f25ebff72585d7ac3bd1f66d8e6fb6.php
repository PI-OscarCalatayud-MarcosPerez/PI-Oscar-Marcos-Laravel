<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MOKeys | Inicio</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/icono.png')); ?>" />
  </head>
  <body>
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> 

    <div class="inicio-container">
       <div class="video-background">
          </div>
       <div class="inicio">
        <p class="textoI">MOKeys: Tu ecommerce de confianza.</p>
       </div>
    </div>

    <div class="carousel-container carrusel-comprados">
      <h2>Juegos más comprados</h2>
      <button class="prev" onclick="moveSlide('lista-comprados', -1)"><img src="<?php echo e(asset('img/izquierda.png')); ?>" /></button>
      
      <div class="carousel" id="lista-comprados">
        <?php $__currentLoopData = $comprados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item" onclick="window.location.href='<?php echo e(route('product.show', $p->id)); ?>'">
                <div class="item-imagen">
                    <img src="<?php echo e(asset($p->imagen_url)); ?>" alt="<?php echo e($p->nombre); ?>" loading="lazy" />
                </div>
                <div class="item-info">
                    <p class="item-titulo"><?php echo e($p->nombre); ?></p>
                    <p class="price"><?php echo e($p->precio); ?>€</p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <button class="next" onclick="moveSlide('lista-comprados', 1)"><img src="<?php echo e(asset('img/derecha.png')); ?>" /></button>
    </div>

    <div class="carousel-container carrusel-ofertas">
      <h2>Mejores Ofertas</h2>
       <div class="carousel" id="lista-ofertas">
        <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="item" onclick="window.location.href='<?php echo e(route('product.show', $p->id)); ?>'">
                <div class="item-imagen"><img src="<?php echo e(asset($p->imagen_url)); ?>" /></div>
                <div class="item-info"><p class="item-titulo"><?php echo e($p->nombre); ?></p><p class="price"><?php echo e($p->precio); ?>€</p></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      </div>

    <div class="carousel-container carrusel-nuevos">
      <h2>Nuevos Lanzamientos</h2>
      <div class="carousel" id="lista-nuevos">
        <?php $__currentLoopData = $nuevos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="item" onclick="window.location.href='<?php echo e(route('product.show', $p->id)); ?>'">
                <div class="item-imagen"><img src="<?php echo e(asset($p->imagen_url)); ?>" /></div>
                <div class="item-info"><p class="item-titulo"><?php echo e($p->nombre); ?></p><p class="price"><?php echo e($p->precio); ?>€</p></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script>
        function moveSlide(id, direction) {
            const container = document.getElementById(id);
            const scrollAmount = 300;
            container.scrollBy({ left: scrollAmount * direction, behavior: 'smooth' });
        }
    </script>
  </body>
</html><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>