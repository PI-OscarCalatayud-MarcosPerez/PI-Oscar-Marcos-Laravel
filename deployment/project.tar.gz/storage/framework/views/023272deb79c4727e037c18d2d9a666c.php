<footer>
  <div class="container">
    <div class="row align-items-center">
      <div class="col-md-3 text-center text-md-start mb-4 mb-md-0">
        <img
          src="<?php echo e(asset('img/imagensincolor.png')); ?>"
          alt="MOKeys"
          class="footer-logo-img"
        />
      </div>
      <div class="col-md-6 text-center mb-4 mb-md-0">
        <div class="d-flex justify-content-center gap-5 footer-enlaces">
          <div class="text-start">
            <h6 class="text-uppercase fw-bold text-white">Help</h6>
            <a href="#">FAQ</a><br /><a href="#">Service</a><br /><a
              href="#"
              >Guides</a
            >
          </div>
          <div class="text-start">
            <h6 class="text-uppercase fw-bold text-white">Other</h6>
            <a href="#">Privacy</a><br /><a href="#">Sitemap</a>
          </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="input-group">
          <input
            type="email"
            class="form-control"
            placeholder="Email address"
            aria-label="Correo electrónico"
          />
          <button class="btn btn-danger" type="button">Comprar</button>
        </div>
      </div>
    </div>
  </div>
</footer><?php /**PATH /var/www/html/resources/views/partials/footer.blade.php ENDPATH**/ ?>