<?php $__env->startSection('title', 'Mi Perfil - MOKeys'); ?>

<?php $__env->startSection('body-class', 'pagina-contacto'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/formulario.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>



    <main class="contenedor-formulario-principal">
        <div class="caja-formulario" style="max-width: 500px;">
            <h2 style="color: #0e273f; text-align: center;">Mi Perfil</h2>
            <p style="text-align: center;">Hola, <strong><?php echo e(Auth::user()->name); ?></strong> 👋</p>

            <?php if(session('status') === 'profile-updated'): ?>
                <div
                    style="background-color: #e8f5e9; color: #2e7d32; padding: 10px; border-radius: 5px; text-align: center; margin-bottom: 15px;">
                    ¡Perfil actualizado con éxito!
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('profile.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div class="grupo-input">
                    <label>Usuario (No editable):</label>
                    <input type="text" value="<?php echo e(Auth::user()->name); ?>" disabled
                        style="background-color: #eee; color: #666;">
                </div>

                <div class="grupo-input">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required value="<?php echo e(old('email', Auth::user()->email)); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span style="color: red; font-size: 0.9em;"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="grupo-input">
                    <label for="name">Nombre:</label>
                    <input type="text" id="name" name="first_name" value="<?php echo e(old('first_name', Auth::user()->name)); ?>">
                    <!-- Nota: Auth::user()->name es el 'username/name' actual. Si se quiere separar nombre real se usaria last_name -->
                </div>

                <div class="grupo-input">
                    <label for="last_name">Apellidos:</label>
                    <input type="text" id="last_name" name="last_name"
                        value="<?php echo e(old('last_name', Auth::user()->last_name)); ?>">
                </div>

                <button type="submit" class="btn-enviar">Guardar Cambios</button>
            </form>

            <div style="text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee;">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); this.closest('form').submit();"
                        style="color: #fa4841; font-weight: bold; text-decoration: none;">Cerrar Sesión</a>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/dashboard.blade.php ENDPATH**/ ?>