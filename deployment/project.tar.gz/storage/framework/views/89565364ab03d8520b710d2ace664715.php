<?php $__env->startSection('title', $product->nombre . ' | MOKeys'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/productos.css')); ?>" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid breadcrumb-container"
        style="background-color: #f8f9fa; padding: 10px 0; margin-bottom: 20px;">
        <div class="container px-md-5">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb" style="margin: 0;">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"
                            style="color:#fa4841; text-decoration:none;">Inicio</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('products.buy')); ?>"
                            style="color:#fa4841; text-decoration:none;">Tienda</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->nombre); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="product-main">
        <main class="product-detail-container">
            <div class="product-image">
                <img id="p-image" src="<?php echo e(asset($product->imagen_url)); ?>" alt="<?php echo e($product->nombre); ?>">
            </div>
            <div class="product-info">
                <h1><?php echo e($product->nombre); ?></h1>
                <span class="product-sku">REF: <?php echo e($product->sku); ?></span>
                <p class="product-price"><?php echo e($product->precio); ?> €</p>
                <span class="product-stock">Stock: <?php echo e($product->stock); ?></span>
                <p class="product-desc"><?php echo e($product->descripcion); ?></p>
                <button class="btn-buy-large">Añadir al Carrito 🛒</button>
            </div>
        </main>

        <section class="reviews-container">
            <div class="reviews-header">
                <h2>Opiniones de la Comunidad</h2>
                <div class="rating-summary">
                    <div class="rating-number"><?php echo e($product->media_estrellas); ?></div>

                    <div class="rating-stars">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <?php if($i <= round($product->media_estrellas)): ?>
                                <span class="filled" style="color: #ffc700;">★</span>
                            <?php else: ?>
                                <span style="color: #ccc;">★</span>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>

                    <div class="rating-count">Basado en <?php echo e($product->reviews->count()); ?> opiniones</div>
                </div>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <?php
                    $userReview = $product->reviews->where('user_id', auth()->id())->first();
                ?>

                <?php if($userReview): ?>
                    <div class="review-form-card"
                        style="text-align: center; background-color: #f8f9fa; border-left: 5px solid #4CAF50;">
                        <h3>¡Gracias por tu opinión!</h3>
                        <p>Ya has valorado este juego con <strong><?php echo e($userReview->estrellas); ?> estrellas</strong>.</p>
                        <p><i>"<?php echo e($userReview->comentario); ?>"</i></p>
                    </div>
                <?php else: ?>
                    <div class="review-form-card">
                        <h3>Deja tu valoración</h3>

                        <?php if($errors->has('review')): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errors->first('review')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('reviews.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                            <div class="rate">
                                <input type="radio" id="star5" name="estrellas" value="5" /><label for="star5">★</label>
                                <input type="radio" id="star4" name="estrellas" value="4" /><label for="star4">★</label>
                                <input type="radio" id="star3" name="estrellas" value="3" /><label for="star3">★</label>
                                <input type="radio" id="star2" name="estrellas" value="2" /><label for="star2">★</label>
                                <input type="radio" id="star1" name="estrellas" value="1" /><label for="star1">★</label>
                            </div>

                            <textarea name="comentario" placeholder="¿Qué te ha parecido el juego?" required></textarea>
                            <button type="submit" class="btn-submit-review">Publicar Opinión</button>
                        </form>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="review-form-card" style="text-align: center;">
                    <p>Debes <a href="<?php echo e(route('login')); ?>" style="color:#fa4841; font-weight:bold;">iniciar sesión</a> para
                        dejar tu valoración.</p>
                </div>
            <?php endif; ?>

            <div class="reviews-list">
                <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="comment-item">
                        <div class="comment-header">
                            <div>
                                <span class="user-name"><?php echo e($review->user->name); ?></span>
                                <span class="comment-stars">
                                    <?php for($j = 1; $j <= 5; $j++): ?>
                                        <span style="color: <?php echo e($j <= $review->estrellas ? '#ffc700' : '#ccc'); ?>;">★</span>
                                    <?php endfor; ?>
                                </span>
                            </div>
                            <span class="comment-date"><?php echo e($review->created_at->format('d/m/Y')); ?></span>
                        </div>
                        <div class="comment-body">
                            <?php echo e($review->comentario); ?>


                            <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
                                <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="POST"
                                    style="display:inline; float:right;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"
                                        onclick="return confirm('¿Seguro que quieres borrar este comentario?')">Borrar</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php if($product->reviews->isEmpty()): ?>
                    <p style="text-align: center; color: #999;">Aún no hay opiniones. ¡Sé el primero!</p>
                <?php endif; ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/products/show.blade.php ENDPATH**/ ?>