<?php $__env->startSection('title', 'Importar Productos - MOKeys'); ?>
<?php $__env->startSection('body-class', 'pagina-contacto'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/estilos.css')); ?>" />
    <style>
        /* Estilos específicos para los mensajes de este proceso (portados del original) */
        .resumen-caja {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 0.9rem;
        }

        .resumen-exito {
            background-color: #e8f5e9;
            border: 1px solid #a5d6a7;
            color: #2e7d32;
        }

        .resumen-error {
            background-color: #ffebee;
            border: 1px solid #ef9a9a;
            color: #c62828;
        }

        .resumen-caja ul {
            margin: 5px 0 0 20px;
            padding: 0;
        }

        .info-columnas {
            font-size: 0.85rem;
            color: #666;
            margin-bottom: 10px;
        }

        .input-fichero {
            background: #f9f9f9;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <main class="contenedor-formulario-principal" id="main-content">
        <div class="caja-formulario">
            <h1>Importación de Productos</h1>
            <p class="subtitulo-form">
                Sube tu archivo CSV para actualizar el catálogo.
            </p>

            <?php if(!empty($messages)): ?>
                <div class="resumen-caja resumen-exito">
                    <strong>Estado:</strong>
                    <ul>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($msg); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php if(isset($importedCount) && $importedCount > 0): ?>
                        <p style="margin-top:10px;">
                            <a href="<?php echo e(route('products.index')); ?>" target="_blank" style="color:#2e7d32; font-weight:bold;">
                                Ver Catálogo Actualizado ➜
                            </a>
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if(!empty($csvErrors)): ?>
                <div class="resumen-caja resumen-error">
                    <strong>⚠️ Errores Críticos:</strong>
                    <ul>
                        <?php $__currentLoopData = $csvErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(!empty($rowErrors)): ?>
                <div class="resumen-caja resumen-error"
                    style="background-color: #fff3e0; border-color: #ffcc80; color: #e65100;">
                    <strong>⚠️ Advertencias (Filas ignoradas):</strong>
                    <ul style="max-height: 100px; overflow-y: auto;">
                        <?php $__currentLoopData = $rowErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($err); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Formulario Laravel -->
            <form action="<?php echo e(route('products.import.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="grupo-input">
                    <label for="arxiuCsv">Seleccionar archivo (.csv):</label>
                    <p class="info-columnas">Columnas requeridas: id, nombre, descripcion, precio, img, estoc, categoria</p>

                    <input type="file" name="arxiuCsv" id="arxiuCsv" required accept=".csv" class="input-fichero">
                    <?php $__errorArgs = ['arxiuCsv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small style="color:red;"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn-enviar">Importar Catálogo</button>
            </form>
        </div>
    </main>

    <div class="container-fluid breadcrumb-container">
        <div class="container px-md-5">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"
                            style="color:#fa4841; text-decoration:none;">Inicio</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Importar</li>
                </ol>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/pages/formulario.blade.php ENDPATH**/ ?>