<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title', 'MOKeys'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
    <link rel="icon" type="image/png" href="<?php echo e(asset('img/icono.png')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
    <?php echo $__env->yieldPushContent('styles'); ?>
  </head>
  <body class="<?php echo $__env->yieldContent('body-class'); ?>">
    
    <div class="aviso-slider">
      <div class="aviso-slider-content">
        <div>Clave de juegos con un 70% de descuento</div>
        <div>¡Nuevas ofertas cada día!</div>
        <div>¡Las claves más baratas de la web!</div>
        <div>Clave de juegos con un 70% de descuento</div>
      </div>
    </div>

    <!-- Header Partial -->
    <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer Partial -->
    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
  </body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>