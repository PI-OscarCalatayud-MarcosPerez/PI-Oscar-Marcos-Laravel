<template>
    <div class="container my-5 text-center">
        <h1>Subir Producto</h1>
        <p class="lead">Esta funcionalidad está en desarrollo.</p>
        <p>Aquí irá el formulario para importar o crear nuevos productos.</p>
        <RouterLink to="/" class="btn btn-primary">Volver al Inicio</RouterLink>
    </div>
</template>
